import { NextResponse } from "next/server";
import { pool } from "@/lib/db";
import { parse } from "csv-parse/sync";
import * as XLSX from "xlsx";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const fileName = file.name.toLowerCase();

    let rows: any[] = [];

    /* ================= FILE TYPE DETECTION ================= */
    const isExcel =
      buffer.slice(0, 2).toString() === "PK" ||
      fileName.endsWith(".xlsx");

    if (isExcel) {
      const workbook = XLSX.read(buffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
        defval: null,
      });
    } else {
      rows = parse(buffer.toString("utf-8"), {
        columns: true,
        skip_empty_lines: true,
        trim: true,
      });
    }

    if (!rows.length) {
      return NextResponse.json(
        { error: "File has no data" },
        { status: 400 }
      );
    }

    /* ================= TABLE DETECTION ================= */
    let table = "";

    if (fileName.includes("employee_details")) {
      table = "employee_details";
    } else if (fileName.includes("employee_salary")) {
      table = "employee_salary_details";
    } else if (fileName.includes("employee_qualification")) {
      table = "employee_qualification_details";
    } else if (fileName.includes("employee_previous")) {
      table = "employee_previous_employment";
    } else {
      return NextResponse.json(
        { error: "Unknown import file" },
        { status: 400 }
      );
    }

    /* ================= SAFE INSERT ================= */
    const columns = Object.keys(rows[0]).filter(
      (c) => c !== "id" && c !== "created_at" && c !== "updated_at"
    );

    for (const row of rows) {
      const values = columns.map((col) => row[col] ?? null);
      const placeholders = columns.map((_, i) => `$${i + 1}`);

      const query = `
        INSERT INTO ${table} (${columns.join(", ")})
        VALUES (${placeholders.join(", ")})
      `;

      await pool.query(query, values);
    }

    return NextResponse.json({
      success: true,
      table,
      inserted: rows.length,
    });
  } catch (err: any) {
    console.error("IMPORT ERROR:", err);
    return NextResponse.json(
      { error: err.message },
      { status: 500 }
    );
  }
}
